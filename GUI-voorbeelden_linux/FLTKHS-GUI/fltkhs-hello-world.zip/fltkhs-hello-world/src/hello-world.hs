{-# LANGUAGE OverloadedStrings #-}
module Main where
import qualified Graphics.UI.FLTK.LowLevel.FL as FL
import Graphics.UI.FLTK.LowLevel.Fl_Types
import Graphics.UI.FLTK.LowLevel.FLTKHS

buttonCb :: Ref Button -> IO ()            --functie voor het togglen als op de Button wordt gedrukt
buttonCb b' = do
  l' <- getLabel b'
  if (l' == "Hello world")
    then setLabel b' "Goodbye world"
    else setLabel b' "Hello world"

ui :: IO ()
ui = do
 window <- windowNew
           (Size (Width 300) (Height 280))  --Size
           Nothing                          --Maybe Position
           (Just "Example FLTKHS application")      --Maybe Text -> Window label naam
 begin window
 b' <- buttonNew
        (Rectangle (Position (X 65) (Y 75)) (Size (Width 195) (Height 130)))
        (Just "Hello world")               --Button label naam
 setLabelsize b' (FontSize 10)
 setCallback b' buttonCb
 end window
 showWidget window

main :: IO ()
main = ui >> FL.run >> FL.flush

replMain :: IO ()
replMain = ui >> FL.replRun
