# fltkhs-hello-world
This is a skeleton app to help get going with a FLTKHS native GUI application. To install clone this repo then do:

    > stack build --flag fltkhs:bundled
    > stack exec fltkhs-hello-world
